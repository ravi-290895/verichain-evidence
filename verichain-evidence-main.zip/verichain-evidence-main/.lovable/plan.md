
# Evidence Protection System — Build Plan

A tamper-proof digital evidence registry with simulated blockchain ledger, role-based access, and full chain-of-custody auditing. Built on Lovable Cloud with a forensic-tech dark UI.

## Visual Design (Surprise Pick)
- **Theme**: Deep midnight navy (`#0A0E1A`) base with electric cyan (`#00E5FF`) accent and a warning amber (`#FFB020`) for tamper alerts
- **Typography**: JetBrains Mono for hashes/IDs, Inter for body, bold display weights for titles
- **Motif**: Hash fingerprints rendered as glowing monospace blocks; "block" cards with subtle border glow; status pills (Verified ✓, Tampered ✗, Pending ⏱)
- **Feel**: Forensic dashboard meets blockchain explorer

## Roles & Auth
- Email/password auth via Lovable Cloud
- Roles stored in dedicated `user_roles` table with security-definer functions (no privilege escalation):
  - **Officer** — Upload evidence, view own cases
  - **Investigator** — Verify evidence, access assigned cases
  - **Judge** — Read-only access to chain of custody + audit logs
  - **Admin** — Manage users/roles, view everything
- First signup auto-promoted to Admin; Admin assigns roles afterward
- A small profiles table for display name + badge ID per user

## Pages
1. **Landing / Login** — branded hero, sign in / sign up
2. **Dashboard** — stats (total evidence, verified today, tampered alerts), recent activity feed, role-aware quick actions
3. **Upload Evidence** (Officer/Admin) — drag-and-drop, auto SHA-256 hash computed in browser, metadata form (case ID, description, location, timestamp), file stored in Cloud Storage, hash + metadata "registered" to ledger table
4. **Verify Evidence** (Investigator/Officer/Admin) — drop any file → re-hash → compare against ledger → verdict screen (Authentic / Tampered / Not Found) with full provenance
5. **Evidence Registry** — searchable/filterable table of all evidence with hash, uploader, timestamp, case ID, status
6. **Evidence Detail** — full record: file preview, hash block, IPFS-style CID, uploader, timestamp, complete chain-of-custody timeline (every view/verify/access logged)
7. **Audit Log** (Judge/Admin) — immutable activity log with filters
8. **Admin — User Management** — assign/revoke roles

## Backend (Lovable Cloud)
- **Tables**: `profiles`, `user_roles`, `evidence_ledger` (hash, cid, metadata, uploader, block_number, prev_hash, block_hash), `custody_log` (evidence_id, actor, action, timestamp)
- **Simulated blockchain**: each new evidence row computes `block_hash = sha256(prev_hash + payload)` so the ledger is chain-linked and tamper-evident — visualized as a "block explorer" view
- **Storage bucket** for actual files (private, signed URLs)
- **RLS policies** enforce role-based read/write
- **Edge function** `register-evidence` performs the chained hashing server-side so clients can't forge blocks
- **Edge function** `verify-evidence` accepts a hash and returns provenance + integrity check

## Roadmap
1. Auth + roles + profiles + RLS
2. Database schema + edge functions for chained ledger
3. Upload flow with browser-side SHA-256 + storage
4. Verify flow with verdict UI
5. Registry, detail page, chain-of-custody timeline
6. Audit log + admin user management
7. Dashboard, polish, dark forensic theme pass

## Question Before Build
**Profile data**: I'll add a `profiles` table storing display name, badge/officer ID, and department (useful for chain-of-custody attribution in court-style records). If you'd rather keep it minimal (just email), say the word and I'll skip profiles.
